package zse.oop.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.List;

class OptionsParserTest {

    @Test
    void testParseValidOptions() {
        String[] args = {"f", "b", "r", "l", "invalid"};
        List<Direction> directions = OptionParser.parse(args);

        assertEquals(4, directions.size());
        assertEquals(Direction.FORWARD, directions.get(0));
        assertEquals(Direction.BACKWARD, directions.get(1));
        assertEquals(Direction.RIGHT, directions.get(2));
        assertEquals(Direction.LEFT, directions.get(3));
    }

    @Test
    void testParseEmptyOptions() {
        String[] args = {};
        List<Direction> directions = OptionParser.parse(args);

        assertTrue(directions.isEmpty());
    }
}