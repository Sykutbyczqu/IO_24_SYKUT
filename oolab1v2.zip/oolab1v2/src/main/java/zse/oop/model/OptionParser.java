package zse.oop.model;

import java.util.ArrayList;
import java.util.List;

public class OptionParser {
    public static List<Direction> parse(String[] args) {
        List<Direction> directions = new ArrayList<>();
        for (String arg : args) {
            switch (arg.toLowerCase()) {
                case "f":
                    directions.add(Direction.FORWARD);
                    break;
                case "b":
                    directions.add(Direction.BACKWARD);
                    break;
                case "r":
                    directions.add(Direction.RIGHT);
                    break;
                case "l":
                    directions.add(Direction.LEFT);
                    break;
                default:

                    break;
            }
        }
        return directions;
    }
}