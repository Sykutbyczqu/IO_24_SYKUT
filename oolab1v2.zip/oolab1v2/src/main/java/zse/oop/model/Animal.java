package zse.oop.model;

public class Animal {
    private MapDirection orientation;
    private Vector2d position;


    public Animal() {
        this.position = new Vector2d(3, 4);
        this.orientation = MapDirection.NORTH;
    }


    public Animal(Vector2d position) {
        this.position = position;
        this.orientation = MapDirection.NORTH;
    }

    @Override
    public String toString() {
        return "Zwierze na pozycji: " + position + ", orientacja: " + orientation;
    }

    public boolean isAt(Vector2d position) {
        return this.position.equals(position);
    }

    public void move(Direction direction) {
        switch (direction) {
            case RIGHT:
                this.orientation = this.orientation.next();
                break;
            case LEFT:
                this.orientation = this.orientation.previous();
                break;
            case FORWARD:
                moveForward();
                break;
            case BACKWARD:
                moveBackward();
                break;
        }
    }

    private void moveForward() {
        Vector2d newPosition = position.add(orientation.toUnitVector());
        if (isWithinBounds(newPosition)) {
            position = newPosition;
        }
    }

    private void moveBackward() {
        Vector2d newPosition = position.subtract(orientation.toUnitVector());
        if (isWithinBounds(newPosition)) {
            position = newPosition;
        }
    }

    private boolean isWithinBounds(Vector2d position) {
        return position.getX() >= 0 && position.getX() <= 4 && position.getY() >= 0 && position.getY() <= 4;
    }
}