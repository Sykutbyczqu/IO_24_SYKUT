package zse.oop.model;


import java.util.ArrayList;
import java.util.List;

public class Simulation {
    private final List<Animal> animals = new ArrayList<>();
    private final List<Direction> directions;

    public Simulation(List<Direction> directions, List<Vector2d> positions) {
        this.directions = directions;
        for (Vector2d position : positions) {
            animals.add(new Animal(position));
        }
    }

    public void run() {
        for (int i = 0; i < directions.size(); i++) {
            Animal animal = animals.get(i % animals.size());
            animal.move(directions.get(i));
            System.out.println("Zwierze " + (i % animals.size()) + ": " + animal);
        }
    }
}